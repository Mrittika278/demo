import type {District,ForecastResponse,ScenarioResult,Signal} from './types';
const get=async<T>(url:string):Promise<T>=>{const r=await fetch(url);if(!r.ok)throw new Error(await r.text());return r.json()};
export const api={
 districts:()=>get<District[]>('/api/regions'),
 forecast:(d:string)=>get<ForecastResponse>(`/api/forecast/${encodeURIComponent(d)}`),
 signals:(d:string)=>get<Signal[]>(`/api/signals/${encodeURIComponent(d)}`),
 scenario:(body:unknown)=>fetch('/api/scenario',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}).then(r=>r.json() as Promise<ScenarioResult>),
 status:()=>get<{data_updated:string;model_updated:string;forecast_generated:string;mode:string}>('/api/data-status')
};
