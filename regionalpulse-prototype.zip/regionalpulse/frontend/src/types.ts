export type Risk = 'NORMAL'|'LOW'|'MODERATE'|'HIGH'|'VERY HIGH';
export type Screen = 'map'|'forecast'|'alert';
export interface District {name:string; lat:number; lng:number; pressure:number; risk:Risk; current:number; demand:number; available:number; gap:number; riskProbability:number; forecast:number[]}
export interface ForecastPoint {label:string; actual?:number; predicted:number; low:number; high:number}
export interface Signal {name:string; source:string; timestamp:string; region:string; severity:string; value:string; contribution:number}
export interface ForecastResponse {district:string; points:ForecastPoint[]; current:number; demand:number; available:number; gap:number; riskProbability:number; trend:number; pressure:number; threshold:number; signals:Signal[]; modelStatus:string; dataStatus:string}
export interface ScenarioResult {baseline:ForecastPoint[]; scenario:ForecastPoint[]; delta:number; gapDelta:number; riskDelta:number}
