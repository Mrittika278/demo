from datetime import datetime, timezone
from math import sin, cos
from typing import Any
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

THRESHOLD=90.0
app=FastAPI(title='RegionalPulse API', version='0.1.0')
app.add_middleware(CORSMiddleware,allow_origins=['http://localhost:5173','http://127.0.0.1:5173'],allow_credentials=True,allow_methods=['*'],allow_headers=['*'])

DISTRICTS=[
('Chennai',13.0827,80.2707),('Coimbatore',11.0168,76.9558),('Madurai',9.9252,78.1198),('Tiruchirappalli',10.7905,78.7047),('Salem',11.6643,78.1460),('Tirunelveli',8.7139,77.7567),('Erode',11.3410,77.7172),('Vellore',12.9165,79.1325),('Thanjavur',10.7870,79.1378),('Dindigul',10.3673,77.9803),('Thoothukudi',8.7642,78.1348),('Kanyakumari',8.0883,77.5385)
]

def seed(name:str)->int:return sum((i+1)*ord(c) for i,c in enumerate(name))
def risk(p:float)->str:return 'VERY HIGH' if p>=95 else 'HIGH' if p>=85 else 'MODERATE' if p>=75 else 'LOW' if p>=65 else 'NORMAL'
def now(): return datetime.now(timezone.utc).astimezone().strftime('%Y-%m-%d %H:%M:%S %Z')

def base(name:str)->dict[str,Any]:
 s=seed(name); current=62+(s%23); available=180+(s%170); demand=int(available*(0.76+((s%11)/100)))
 trend=2+(s%7); forecasts=[round(current+trend*i+(s%5)*0.2,1) for i in range(1,4)]; pressure=forecasts[-1]
 gap=available-int(available*pressure/100); rp=min(98,max(8,int((pressure-58)*2.3)))
 return dict(name=name,lat=next(x[1] for x in DISTRICTS if x[0]==name),lng=next(x[2] for x in DISTRICTS if x[0]==name),pressure=pressure,risk=risk(pressure),current=current,demand=demand,available=available,gap=gap,riskProbability=rp,forecast=forecasts)

@app.get('/api/health')
def health(): return {'status':'ok','mode':'DEMO / SIMULATED'}
@app.get('/api/data-status')
def status():
 t=now();return {'data_updated':t,'model_updated':t,'forecast_generated':t,'mode':'DEMO / SIMULATED'}
@app.get('/api/regions')
def regions(): return [base(n) for n,_,_ in DISTRICTS]
@app.get('/api/regions/{district}')
def region(district:str): return base(district)
@app.get('/api/hospitals')
def hospitals(): return {'mode':'DEMO / SIMULATED','hospitals':[]}

def signals(name:str):
 s=seed(name); ts=now(); return [
 {'name':'Admission trend','source':'Demo hospital feed','timestamp':ts,'region':name,'severity':'Elevated','value':f'+{3+s%6}% trend','contribution':22+s%16},
 {'name':'Weather','source':'Demo weather connector','timestamp':ts,'region':name,'severity':'Moderate','value':f'{25+s%8} mm forecast rainfall','contribution':16+s%13},
 {'name':'Public event','source':'Demo event feed','timestamp':ts,'region':name,'severity':'Moderate','value':'population concentration signal','contribution':12+s%12},
 {'name':'Disease signal','source':'Demo surveillance connector','timestamp':ts,'region':name,'severity':'Elevated','value':'dengue signal index','contribution':11+s%11},
 {'name':'Mobility','source':'Demo mobility connector','timestamp':ts,'region':name,'severity':'Moderate','value':f'+{2+s%8}% index','contribution':8+s%9},
 {'name':'Other','source':'Derived demo features','timestamp':ts,'region':name,'severity':'Low','value':'other multimodal features','contribution':5+s%6},]
@app.get('/api/signals/{district}')
def get_signals(district:str):return signals(district)
@app.get('/api/events')
def events():return {'mode':'DEMO / SIMULATED','events':[]}
@app.get('/api/weather')
def weather():return {'mode':'DEMO / SIMULATED','observations':[]}
@app.get('/api/disease-signals')
def diseases():return {'mode':'DEMO / SIMULATED','signals':[]}
@app.get('/api/forecast/{district}')
def forecast(district:str):
 b=base(district); points=[]; labels=['-72h','-48h','-24h','NOW','+24h','+48h','+72h']; s=seed(district)
 for i,l in enumerate(labels):
  if i<4: val=round(b['current']-((3-i)*1.8)-(s%4)*.2,1); points.append({'label':l,'actual':val,'predicted':val,'low':val,'high':val})
  else:
   val=b['forecast'][i-4]; points.append({'label':l,'predicted':val,'low':round(val-3.2,1),'high':round(val+3.2,1)})
 return {'district':district,'points':points,'current':b['current'],'demand':b['demand'],'available':b['available'],'gap':b['gap'],'riskProbability':b['riskProbability'],'trend':round(b['forecast'][-1]-b['current'],1),'pressure':b['pressure'],'threshold':THRESHOLD,'signals':signals(district),'modelStatus':'Deterministic demo inference — not trained clinical ML','dataStatus':'DEMO / SIMULATED'}

class Scenario(BaseModel):
 district:str; scenario:str; intensity:int=Field(ge=0,le=100); duration:int=Field(ge=1,le=168)
@app.post('/api/scenario')
def scenario(x:Scenario):
 f=forecast(x.district); factor={'Large Mass Gathering':.12,'Heavy Rainfall':.10,'Heatwave':.07,'Disease Surge':.15,'Major Accident':.13,'Industrial Incident':.14}.get(x.scenario,.1)
 lift=round(factor*(x.intensity/100)*min(1,x.duration/24)*100,1)
 scen=[{**p,'predicted':round(p['predicted']+lift,1),'low':round(p['low']+lift,1),'high':round(p['high']+lift,1)} for p in f['points']]
 return {'baseline':f['points'],'scenario':scen,'delta':lift,'gapDelta':-round(f['available']*lift/100),'riskDelta':min(99,max(0,f['riskProbability']+round(lift*1.2)-f['riskProbability']))}
